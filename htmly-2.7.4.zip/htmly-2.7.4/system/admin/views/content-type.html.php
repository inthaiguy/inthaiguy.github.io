<h2>Add content</h2>

<p><a href="<?php echo site_url();?>add/content?type=post">Regular post</a><br>Creating regular blog post.</p>
<p><a href="<?php echo site_url();?>add/content?type=image">Image post</a><br>Creating blog post with featured image.</p>
<p><a href="<?php echo site_url();?>add/content?type=video">Video post</a><br>Creating blog post with featured video.</p>
<p><a href="<?php echo site_url();?>add/content?type=audio">Audio post</a><br>Creating blog post with featured audio.</p>
<p><a href="<?php echo site_url();?>add/content?type=link">Link post</a><br>Creating blog post with featured link.</p>
<p><a href="<?php echo site_url();?>add/content?type=quote">Quote post</a><br>Creating blog post with featured quote.</p>
<p><a href="<?php echo site_url();?>add/page">Static page</a><br>Creating static page.</p>