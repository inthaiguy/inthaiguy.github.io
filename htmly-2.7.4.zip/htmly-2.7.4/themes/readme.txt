Place your theme folder here, but don't modify the default theme. Doing so may cause merge conflicts or overrides in your custom changes.
